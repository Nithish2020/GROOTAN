const express = require('express')
const path = require('path');
const fs = require("fs");
const bodyParser = require('body-parser');
const multer = require("multer");
const axios = require("axios");
const base64 = require("base-64");
const freshdesk = require('@freshworks/freshdesk');
const xlsx = require('xlsx');

const myCSS = {
    style : fs.readFileSync('./css/styles.css','utf8')
};

const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.use(express.static('upload'));
app.set('views', path.join(__dirname, './views'));

async function errorHandler(req, res){
    let errormessage = "";
    let flag = false;
    let domainUrl = req.body.url;
    let apiKey = req.body.key;
    let type = req.file ? ((req.file.filename).split('.')).slice(-1)[0] : null;
    //console.log(type);

    if(!req.file){
        flag = true;
        errormessage = 'No file was uploaded';
    } else if(!(['csv', 'xlsx', 'xls'].includes(type))){
        //console.log('here');
        flag = true;
        errormessage = 'Invalid file type';
        //console.log(flag, errormessage);
    } 
    // else {
    //     let fd = new freshdesk({ domain: domainUrl, api_key: apiKey });
    //     try {
    //         let value = await fd.ticketFields.getAllTicketFields();
    //     } catch(error) {
    //         flag = true;
    //         errormessage = 'Please check your API endpoint credentials';
    //     }
    // }
    
    
    
    if (flag){
        res.render('display.ejs', {
            title: 'Summary Display',
            myCss: myCSS,
            errormessage: errormessage
        });
    }
}

async function getData(filePath, type){
    let data = []
    let finalData = [];
    if (type != 'text/csv'){
        let workbook = xlsx.readFile(filePath);
        let sheets = workbook.SheetNames;
        for (let i = 0; i < sheets.length; i++){
            data.push(xlsx.utils.sheet_to_csv(workbook.Sheets[sheets[i]]));
        }
    }
    else{
        data.push(fs.readFileSync(filePath, 'utf-8'));
    }
    for (let i = 0; i < data.length; i++){
        data[i] = data[i].replace(/[^\w\s]/gi, ' ').trim();
        data[i] = data[i].split(' ');
        finalData.push(...data[i]);
    }
    return finalData;
}


function filterMagicNumbers(data){
    const re = /^[a-zA-Z]{2}\d*$/;
    let number = data.slice(2);
    number = (parseInt(number, 10)).toString();
    return ([2,3,4].includes(number.length) && number != 'NaN' && re.test(data))? true : false;
}

function filterNumbers(data){
    let number = data.slice(2);
    number = (parseInt(number, 10)).toString();
    return number;
}

async function ticketSummary(ticketNumbers, domainUrl, APIkey){
    let token = base64.encode(APIkey);
    let summary = {};

    const headers = {
        headers: {
            'Authorization': `Basic ${token}`
        }
    }

    let url = 'https://' + domainUrl +'/api/v2/tickets/';

    for (let currentTicket of ticketNumbers){
        try{
            let response = await axios.get(url + currentTicket, headers);
            summary[currentTicket] = response.data.subject? response.data.subject:'No Subject';
        } catch(error){
            summary[currentTicket] = 'Ticket not found';
        }
    }
    return summary;
}

let storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, 'uploads/');
    },

    filename: function(req, file, cb) {
        cb(null, file.originalname);
    }
});


const upload = multer({ storage: storage });
app.use(bodyParser.urlencoded({ extended: true }));


app.get('/',function (req, res) {
    res.render('display.ejs', {
        title: 'Summary Display',
        myCss: myCSS,
        errormessage: ''
       });
});

app.post("/postFile", upload.single("files"), async function(req, res){
    await errorHandler(req, res);
    console.log('passed error check!');

    let filePath = 'uploads/' + req.file.filename;
    let data = await getData(filePath, req.file.mimetype);
    console.log('got the data');
    
    filteredData = data.filter(filterMagicNumbers);
    ticketNumbers = filteredData.map(filterNumbers);
    ticketNumbers = new Set(ticketNumbers);
    console.log('filtered the data');

    let summary = await ticketSummary(ticketNumbers, req.body.url, req.body.key);
    console.log('got the summary');

    res.render('table.ejs', {
        title: 'Summary Display',
        myCss: myCSS,
        data: summary
       });
});

app.get('/health',function (req, res) {
    res.send('ok');
});


app.listen(port, () => {
    console.log(`App started on port ${port}!`)
});